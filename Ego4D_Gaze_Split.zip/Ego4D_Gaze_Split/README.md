## Ego4D Download

1. The Ego4D dataset could be downloaded following the [official instructions](https://ego4d-data.org/docs/start-here/).

2. We only need to download the videos with gaze annotations. The labels and video ids can be found [here](https://ego4d-data.org/docs/data/gaze/).

3. Gaze annotations are organized in a bunch of csv files. Each file corresponds to a video. Unfortunately, Ego4D hasn't provided a command to download all of these videos yet. You need to download videos via the video ids (i.e. the name of each csv file) using the [CLI tool](https://ego4d-data.org/docs/CLI/) and `--video_uids`.

4. Please reorganize the video clips and annotations in this structure:

```
Ego4D
|_ full_scale.gaze
|  |_ 0d271871-c8ba-4249-9434-d39ce0060e58.mp4
|  |_ 1e83c2d1-ff03-4181-9ab5-a3e396f54a93.mp4
|  |_ 2bb31b69-fcda-4f54-8338-f590944df999.mp4
|  |_ ...
|
|_ gaze
   |_ 0d271871-c8ba-4249-9434-d39ce0060e58.csv
   |_ 1e83c2d1-ff03-4181-9ab5-a3e396f54a93.csv
   |_ 2bb31b69-fcda-4f54-8338-f590944df999.csv
   |_ ...
```



## Ego4D Data Split

There's no official split for gaze estimation on Ego4D. We provide our own split. There are two csv files -- `train_ego4d_gaze.csv` and `test_ego4d_gaze.csv` containing video clips for training and testing, respectively. We trimmed all videos into lots of 5-second clips for training and testing. Each row in the two csv files is a video clip. For example, you can see a row like `0d271871-c8ba-4249-9434-d39ce0060e58/0d271871-c8ba-4249-9434-d39ce0060e58_t0_t5.mp4`  which indicates a clip trimmed from video `0d271871-c8ba-4249-9434-d39ce0060e58.mp4` from 0s (**included**) to 5s (**not included**). 

Note that we dropped many clips for various reasons (e.g. camera is blocked, the wearer closed eyes, camera is taken off). You can find all dropped clips in `ego4d_gaze_untracked.csv`. We provide the video id, clip start time, clip end time and reason index (1- blurred 2- eyes are closed 3 - camera is taken off  4 - blocked) for each dropped clip.

To make things easier, you can use the scripts in our [released codes](https://github.com/BolinLai/GLC) to complete all the preprocessing of data.

